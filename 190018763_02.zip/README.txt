A função usleep() depende da velocidade do processador, podendo apresentar comportamento diferente em outros computadores. 
Foi adicionada a capacidade de replay nas partidas, além do modo ranqueado.
O jogador somente pode ter sua pontuação salva no modo ranqueado se esta for >= 0. Não vi sentido em ter pontuação zero no ranking :)
Tentei deixar o joguinho mais colorido.
